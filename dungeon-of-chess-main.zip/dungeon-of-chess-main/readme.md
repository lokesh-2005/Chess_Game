# dungeon of sdl2

Hello this is a chess game made in SDL2 and GL3, with fews of features (cursed immediate tessellator).
The game contains a primitve workable IA to play.

The IA is primitve but is smart at some point.

# build

To build is easy, just import the build file in sublime_text_build.
I coded this in sublime text so I made this build file.
The program uses MinGW64, anyway this is not a serious project.

# running

Download the repository using git clone or here directly, then just open `build/` folder and launch the executable.  
I do not see any reason to compile under Linux, but if you want to, please, thank you. 

# splash

![Alt text](/splash/splash_gameplay_1.png?raw=true)
![Alt text](/splash/splash_gameplay_2.png?raw=true)
